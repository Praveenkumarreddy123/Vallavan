<?php include_once("header.php"); ?>
	<div id="primary" class="about_page PageSectionCommonPadding">
		 <div class="main_block">
             <div class="About_section_card">
                 <h2 class="section_card_title mb-0">About us</h2>
                 <p class="m-0 section_card_para">The IndoUkB2B is a Networking Organization of Indian Entrepreneurs, Professionals and Enthusiasts. They support each other for mutual growth. They have a clear commitment towards common good, particularly Indian language, culture and community.</p>
                 <div class="clearfix30"></div>
             </div>
         </div>
	</div>
<?php include_once("footer.php"); ?>