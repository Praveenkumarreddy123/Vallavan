export const environment = {
  production: false,
  version: 'Dev',
  WebServiceUrl : 'http://localhost/projects/IndoUKB2B-api',
  relpath: '/Projects/Workplace/INDOUKB2B/'
 // WebServiceUrl : 'https://betaindukpraveenfreelancer.000webhostapp.com/IndoUKB2B-api/IndoUKB2B-api/',
 // relpath: '/INDOUKB2B/'
};
