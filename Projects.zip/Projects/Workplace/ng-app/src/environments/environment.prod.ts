export const environment = {
  production: true,
  WebServiceUrl : 'https://betaindukpraveenfreelancer.000webhostapp.com/IndoUKB2B-api/IndoUKB2B-api/',
  relpath: '/INDOUKB2B/'
};
