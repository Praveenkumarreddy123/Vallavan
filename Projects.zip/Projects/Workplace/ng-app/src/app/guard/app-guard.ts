// import { CanActivate } from '@angular/router';
// import { Injectable } from '@angular/core';
// import {Router } from '@angular/router';
// @Injectable()
// export class AlwaysAuthGuard implements CanActivate  {
//     constructor(private router: Router) { }
//     canActivate() {
//         if (this.global.userToken !== '' || this.global.userToken === undefined ) {
//             this.router.navigate(['/home']);
//              return false;
//         }
//         return true;
//     }
// }
