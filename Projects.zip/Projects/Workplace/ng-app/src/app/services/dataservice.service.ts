import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
@Injectable()
export class DataserviceService {
  WebServiceUrl = environment.WebServiceUrl;
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json'
    })
  };
  constructor(private http: HttpClient) {}
  public listUser() {
    return this.http.get(this.WebServiceUrl + '/api/users');
  }
  public sigleUser() {
    return this.http.get(this.WebServiceUrl + '/api/users');
  }

  public getTenderDetails() {
    return this.http.get(this.WebServiceUrl + '/tender/TenderDetails');
  }

  public createTender(data) {
    // /tender/CreateTender
    return this.http.post(this.WebServiceUrl + '/file-upload.php',
    {
      'name': 'praveen',
      'description': 'kumar',
      'document': data
    }
    );
  }
}
