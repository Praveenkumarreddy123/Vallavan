import { Component, OnInit } from '@angular/core';
import {FormsModule, NgForm} from '@angular/forms';
import { DataserviceService } from 'src/app/services/dataservice.service';
import { Tender } from 'src/app/classes/tender';
@Component({
  selector: 'app-create-tender',
  templateUrl: './create-tender.component.html',
  styleUrls: ['./create-tender.component.scss']
})
export class CreateTenderComponent implements OnInit {

  public createTenderObj = new Tender();

  constructor(public service: DataserviceService) { }

  ngOnInit() {
  }


  OnCreateTender(createTenderObj: Tender) {
   // console.log(this.createTenderObj.Tender_Document.name);
  }

  OnfileChange(event: any) {
    this.createTenderObj.Tender_Document = <File>event.target.files[0];
    // const filetype = event.target.files === 'application/pdf' ?  this.createTenderObj.Tender_Document = event : this.createTenderObj.Tender_Document = null;
  }

  oncreateTenderSubmit(createTenderForm: NgForm) {
    const fd = new FormData();
    fd.append('image', this.createTenderObj.Tender_Document, this.createTenderObj.Tender_Document.name);
    console.log(this.createTenderObj.Tender_Document);
    console.log(fd);
    this.service.createTender(fd).subscribe((data) => {
      console.log(data);
    });
  }
}
