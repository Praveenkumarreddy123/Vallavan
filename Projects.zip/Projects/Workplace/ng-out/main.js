(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n<router-outlet></router-outlet>\r\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'digital-market';
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_opprotunites_opprotunites_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/opprotunites/opprotunites.component */ "./src/app/components/opprotunites/opprotunites.component.ts");
/* harmony import */ var _route_app_routing_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./route/app-routing.module */ "./src/app/route/app-routing.module.ts");
/* harmony import */ var _components_create_tender_create_tender_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/create-tender/create-tender.component */ "./src/app/components/create-tender/create-tender.component.ts");
/* harmony import */ var _services_dataservice_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./services/dataservice.service */ "./src/app/services/dataservice.service.ts");
/* harmony import */ var _classes_tender__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./classes/tender */ "./src/app/classes/tender.ts");
/* harmony import */ var _pipes_removeTime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./pipes/removeTime */ "./src/app/pipes/removeTime.ts");
/* harmony import */ var _pipes_tendersearchbyindustry__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./pipes/tendersearchbyindustry */ "./src/app/pipes/tendersearchbyindustry.ts");
















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"],
                _components_opprotunites_opprotunites_component__WEBPACK_IMPORTED_MODULE_9__["OpprotunitesComponent"],
                _components_create_tender_create_tender_component__WEBPACK_IMPORTED_MODULE_11__["CreateTenderComponent"],
                _pipes_removeTime__WEBPACK_IMPORTED_MODULE_14__["RemoveTime"],
                _pipes_tendersearchbyindustry__WEBPACK_IMPORTED_MODULE_15__["FilterTender"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_4__["HttpModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_8__["RouterModule"],
                _route_app_routing_module__WEBPACK_IMPORTED_MODULE_10__["APP_ROUTING"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"]
            ],
            providers: [_services_dataservice_service__WEBPACK_IMPORTED_MODULE_12__["DataserviceService"], _classes_tender__WEBPACK_IMPORTED_MODULE_13__["Tender"], _classes_tender__WEBPACK_IMPORTED_MODULE_13__["SearchTenderFilter"], { provide: _angular_common__WEBPACK_IMPORTED_MODULE_3__["APP_BASE_HREF"], useValue: '/Projects/Workplace/INDOUKB2B/' }],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/classes/tender.ts":
/*!***********************************!*\
  !*** ./src/app/classes/tender.ts ***!
  \***********************************/
/*! exports provided: Tender, SearchTenderFilter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tender", function() { return Tender; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchTenderFilter", function() { return SearchTenderFilter; });
var Tender = /** @class */ (function () {
    function Tender() {
    }
    return Tender;
}());

var SearchTenderFilter = /** @class */ (function () {
    function SearchTenderFilter() {
    }
    return SearchTenderFilter;
}());



/***/ }),

/***/ "./src/app/components/create-tender/create-tender.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/components/create-tender/create-tender.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"create-tender\">\n    <div  class=\"container\">\n        <h5 class=\"text-black text-center mt-5\">Tender Creation</h5>\n      <div class=\"FormContainer bg-white\">\n        <form autocomplete=\"off\" #createTender=\"ngForm\" action=\"file-upload.php\" method=\"POST\" (ngSubmit)=\"oncreateTenderSubmit(createTender)\" name=\"createTender\" novalidate>\n            <div class=\"SignUpform step-1 \">\n                <div class=\"row\">\n                    <div class=\"col-12 col-sm-12 col-md-12 col-lg-12\">\n                        <div class=\"form-group\">\n                            <label for=\"tender_title\">Tender Title</label>\n                            <input type=\"text\" class=\"error\" name=\"tender_title\" id=\"tender_title\" aria-describedby=\"Tender Title\" ngModel>  \n                            <span class=\"error\">Tender Title is required</span>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"form-group\">\n                    <div class=\"form-group\">\n                        <label for=\"Contract_Type\" class=\"requiredFld\">Contract Type</label>\n                        <select class=\"custom-select\" name=\"Contract_Type\" id=\"Contract_Type\" ngModel>\n                            <option selected=\"\">--Select--</option>\n                            <option value=\"1\">Resource Based</option>\n                            <option value=\"2\">Project Based</option>\n                            <option value=\"3\">Timeline &amp; Material</option>\n                            <option value=\"4\">Training Services</option>\n                            <option value=\"5\">Consultancy Services</option>\n                            <option value=\"6\">Agri Products/Commodities</option>\n                            <option value=\"7\">Other Services</option>\n                        </select>\n                        <span class=\"error\">Contract Type is required</span>\n                    </div>\n                </div>\n                <div class=\"form-group\">\n                    <label for=\"exampleInputEmail1\" class=\"requiredFld\">Industries</label>\n                    <select class=\"custom-select\" name=\"Industry\" id=\"Industry\" ngModel>\n                        <option selected=\"\">--Select--</option>\n                        <option value=\"1\">Accounting/Auditing/Taxation</option>\n                        <option value=\"2\">Admin/Human Resources</option>\n                        <option value=\"3\">Arts/Media/Communications</option>\n                        <option value=\"4\">Industries &amp; Suppliers\n                        </option>\n                        <option value=\"5\">Real Estate</option>\n                        <option value=\"6\">Computer/Information Technology</option>\n                        <option value=\"7\">Education/Training</option>\n                        <option value=\"8\">Electronics/Electricals</option>\n                        <option value=\"9\">Events/Promotions</option>\n                        <option value=\"10\">Garments\n                        </option>\n                        <option value=\"11\">Logistic/Supply chain</option>\n                        <option value=\"12\">Healthcare/Pharmaceutical</option>\n                        <option value=\"13\">Hotel/Restaurant</option>\n                        <option value=\"14\">Manufacturing</option>\n                        <option value=\"15\">Sales/Marketing</option>\n                        <option value=\"16\">Agri Prodcuts/Commodities</option>\n                        <option value=\"17\">Others Services</option>\n                    </select>\n                    <span class=\"error\">Industries is required</span>\n                </div>\n                <div class=\"form-group\">\n                    <label for=\"tender_Country\" class=\"requiredFld\">Country</label>\n                    <select class=\"custom-select\" name=\"Country\" id=\"Country\" ngModel>\n                        <option value=\"1\">India</option>\n                        <option value=\"2\">Albania</option>\n                        <option value=\"3\">Algeria</option>\n                        <option value=\"4\">American Samoa</option>\n                        <option value=\"5\">Andorra</option>\n                        <option value=\"6\">Angola</option>\n                        <option value=\"7\">Anguilla</option>\n                        <option value=\"8\">Antarctica</option>\n                        <option value=\"9\">Antigua And Barbuda</option>\n                        <option value=\"10\">Argentina</option>\n                        <option value=\"11\">Armenia</option>\n                        <option value=\"12\">Aruba</option>\n                        <option value=\"13\">Australia</option>\n                        <option value=\"14\">Austria</option>\n                        <option value=\"15\">Azerbaijan</option>\n                        <option value=\"16\">Bahamas The</option>\n                        <option value=\"17\">Bahrain</option>\n                        <option value=\"18\">Bangladesh</option>\n                        <option value=\"19\">Barbados</option>\n                        <option value=\"20\">Belarus</option>\n                        <option value=\"21\">Belgium</option>\n                        <option value=\"22\">Belize</option>\n                        <option value=\"23\">Benin</option>\n                        <option value=\"24\">Bermuda</option>\n                        <option value=\"25\">Bhutan</option>\n                        <option value=\"26\">Bolivia</option>\n                        <option value=\"27\">Bosnia and Herzegovina</option>\n                        <option value=\"28\">Botswana</option>\n                        <option value=\"29\">Bouvet Island</option>\n                        <option value=\"30\">Brazil</option>\n                        <option value=\"31\">British Indian Ocean Territory</option>\n                        <option value=\"32\">Brunei</option>\n                        <option value=\"33\">Bulgaria</option>\n                        <option value=\"34\">Burkina Faso</option>\n                        <option value=\"35\">Burundi</option>\n                        <option value=\"36\">Cambodia</option>\n                        <option value=\"37\">Cameroon</option>\n                        <option value=\"38\">Canada</option>\n                        <option value=\"39\">Cape Verde</option>\n                        <option value=\"40\">Cayman Islands</option>\n                        <option value=\"41\">Central African Republic</option>\n                        <option value=\"42\">Chad</option>\n                        <option value=\"43\">Chile</option>\n                        <option value=\"44\">China</option>\n                        <option value=\"45\">Christmas Island</option>\n                        <option value=\"46\">Cocos (Keeling) Islands</option>\n                        <option value=\"47\">Colombia</option>\n                        <option value=\"48\">Comoros</option>\n                        <option value=\"49\">Republic Of The Congo</option>\n                        <option value=\"50\">Democratic Republic Of The Congo</option>\n                        <option value=\"51\">Cook Islands</option>\n                        <option value=\"52\">Costa Rica</option>\n                        <option value=\"53\">Cote D'Ivoire (Ivory Coast)</option>\n                        <option value=\"54\">Croatia (Hrvatska)</option>\n                        <option value=\"55\">Cuba</option>\n                        <option value=\"56\">Cyprus</option>\n                        <option value=\"57\">Czech Republic</option>\n                        <option value=\"58\">Denmark</option>\n                        <option value=\"59\">Djibouti</option>\n                        <option value=\"60\">Dominica</option>\n                        <option value=\"61\">Dominican Republic</option>\n                        <option value=\"62\">East Timor</option>\n                        <option value=\"63\">Ecuador</option>\n                        <option value=\"64\">Egypt</option>\n                        <option value=\"65\">El Salvador</option>\n                        <option value=\"66\">Equatorial Guinea</option>\n                        <option value=\"67\">Eritrea</option>\n                        <option value=\"68\">Estonia</option>\n                        <option value=\"69\">Ethiopia</option>\n                        <option value=\"70\">External Territories of Australia</option>\n                        <option value=\"71\">Falkland Islands</option>\n                        <option value=\"72\">Faroe Islands</option>\n                        <option value=\"73\">Fiji Islands</option>\n                        <option value=\"74\">Finland</option>\n                        <option value=\"75\">France</option>\n                        <option value=\"76\">French Guiana</option>\n                        <option value=\"77\">French Polynesia</option>\n                        <option value=\"78\">French Southern Territories</option>\n                        <option value=\"79\">Gabon</option>\n                        <option value=\"80\">Gambia The</option>\n                        <option value=\"81\">Georgia</option>\n                        <option value=\"82\">Germany</option>\n                        <option value=\"83\">Ghana</option>\n                        <option value=\"84\">Gibraltar</option>\n                        <option value=\"85\">Greece</option>\n                        <option value=\"86\">Greenland</option>\n                        <option value=\"87\">Grenada</option>\n                        <option value=\"88\">Guadeloupe</option>\n                        <option value=\"89\">Guam</option>\n                        <option value=\"90\">Guatemala</option>\n                        <option value=\"91\">Guernsey and Alderney</option>\n                        <option value=\"92\">Guinea</option>\n                        <option value=\"93\">Guinea-Bissau</option>\n                        <option value=\"94\">Guyana</option>\n                        <option value=\"95\">Haiti</option>\n                        <option value=\"96\">Heard and McDonald Islands</option>\n                        <option value=\"97\">Honduras</option>\n                        <option value=\"98\">Hong Kong S.A.R.</option>\n                        <option value=\"99\">Hungary</option>\n                        <option value=\"100\">Iceland</option> \n                        <option value=\"102\">Indonesia</option>\n                        <option value=\"103\">Iran</option>\n                        <option value=\"104\">Iraq</option>\n                        <option value=\"105\">Ireland</option>\n                        <option value=\"106\">Israel</option>\n                        <option value=\"107\">Italy</option>\n                        <option value=\"108\">Jamaica</option>\n                        <option value=\"109\">Japan</option>\n                        <option value=\"110\">Jersey</option>\n                        <option value=\"111\">Jordan</option>\n                        <option value=\"112\">Kazakhstan</option>\n                        <option value=\"113\">Kenya</option>\n                        <option value=\"114\">Kiribati</option>\n                        <option value=\"115\">Korea North</option>\n                        <option value=\"116\">Korea South</option>\n                        <option value=\"117\">Kuwait</option>\n                        <option value=\"118\">Kyrgyzstan</option>\n                        <option value=\"119\">Laos</option>\n                        <option value=\"120\">Latvia</option>\n                        <option value=\"121\">Lebanon</option>\n                        <option value=\"122\">Lesotho</option>\n                        <option value=\"123\">Liberia</option>\n                        <option value=\"124\">Libya</option>\n                        <option value=\"125\">Liechtenstein</option>\n                        <option value=\"126\">Lithuania</option>\n                        <option value=\"127\">Luxembourg</option>\n                        <option value=\"128\">Macau S.A.R.</option>\n                        <option value=\"129\">Macedonia</option>\n                        <option value=\"130\">Madagascar</option>\n                        <option value=\"131\">Malawi</option>\n                        <option value=\"132\">Malaysia</option>\n                        <option value=\"133\">Maldives</option>\n                        <option value=\"134\">Mali</option>\n                        <option value=\"135\">Malta</option>\n                        <option value=\"136\">Man (Isle of)</option>\n                        <option value=\"137\">Marshall Islands</option>\n                        <option value=\"138\">Martinique</option>\n                        <option value=\"139\">Mauritania</option>\n                        <option value=\"140\">Mauritius</option>\n                        <option value=\"141\">Mayotte</option>\n                        <option value=\"142\">Mexico</option>\n                        <option value=\"143\">Micronesia</option>\n                        <option value=\"144\">Moldova</option>\n                        <option value=\"145\">Monaco</option>\n                        <option value=\"146\">Mongolia</option>\n                        <option value=\"147\">Montserrat</option>\n                        <option value=\"148\">Morocco</option>\n                        <option value=\"149\">Mozambique</option>\n                        <option value=\"150\">Myanmar</option>\n                        <option value=\"151\">Namibia</option>\n                        <option value=\"152\">Nauru</option>\n                        <option value=\"153\">Nepal</option>\n                        <option value=\"154\">Netherlands Antilles</option>\n                        <option value=\"155\">Netherlands The</option>\n                        <option value=\"156\">New Caledonia</option>\n                        <option value=\"157\">New Zealand</option>\n                        <option value=\"158\">Nicaragua</option>\n                        <option value=\"159\">Niger</option>\n                        <option value=\"160\">Nigeria</option>\n                        <option value=\"161\">Niue</option>\n                        <option value=\"162\">Norfolk Island</option>\n                        <option value=\"163\">Northern Mariana Islands</option>\n                        <option value=\"164\">Norway</option>\n                        <option value=\"165\">Oman</option>\n                        <option value=\"166\">Pakistan</option>\n                        <option value=\"167\">Palau</option>\n                        <option value=\"168\">Palestinian Territory Occupied</option>\n                        <option value=\"169\">Panama</option>\n                        <option value=\"170\">Papua new Guinea</option>\n                        <option value=\"171\">Paraguay</option>\n                        <option value=\"172\">Peru</option>\n                        <option value=\"173\">Philippines</option>\n                        <option value=\"174\">Pitcairn Island</option>\n                        <option value=\"175\">Poland</option>\n                        <option value=\"176\">Portugal</option>\n                        <option value=\"177\">Puerto Rico</option>\n                        <option value=\"178\">Qatar</option>\n                        <option value=\"179\">Reunion</option>\n                        <option value=\"180\">Romania</option>\n                        <option value=\"181\">Russia</option>\n                        <option value=\"182\">Rwanda</option>\n                        <option value=\"183\">Saint Helena</option>\n                        <option value=\"184\">Saint Kitts And Nevis</option>\n                        <option value=\"185\">Saint Lucia</option>\n                        <option value=\"186\">Saint Pierre and Miquelon</option>\n                        <option value=\"187\">Saint Vincent And The Grenadines</option>\n                        <option value=\"188\">Samoa</option>\n                        <option value=\"189\">San Marino</option>\n                        <option value=\"190\">Sao Tome and Principe</option>\n                        <option value=\"191\">Saudi Arabia</option>\n                        <option value=\"192\">Senegal</option>\n                        <option value=\"193\">Serbia</option>\n                        <option value=\"194\">Seychelles</option>\n                        <option value=\"195\">Sierra Leone</option>\n                        <option value=\"196\">Singapore</option>\n                        <option value=\"197\">Slovakia</option>\n                        <option value=\"198\">Slovenia</option>\n                        <option value=\"199\">Smaller Territories of the UK</option>\n                        <option value=\"200\">Solomon Islands</option>\n                        <option value=\"201\">Somalia</option>\n                        <option value=\"202\">South Africa</option>\n                        <option value=\"203\">South Georgia</option>\n                        <option value=\"204\">South Sudan</option>\n                        <option value=\"205\">Spain</option>\n                        <option value=\"206\">Sri Lanka</option>\n                        <option value=\"207\">Sudan</option>\n                        <option value=\"208\">Suriname</option>\n                        <option value=\"209\">Svalbard And Jan Mayen Islands</option>\n                        <option value=\"210\">Swaziland</option>\n                        <option value=\"211\">Sweden</option>\n                        <option value=\"212\">Switzerland</option>\n                        <option value=\"213\">Syria</option>\n                        <option value=\"214\">Taiwan</option>\n                        <option value=\"215\">Tajikistan</option>\n                        <option value=\"216\">Tanzania</option>\n                        <option value=\"217\">Thailand</option>\n                        <option value=\"218\">Togo</option>\n                        <option value=\"219\">Tokelau</option>\n                        <option value=\"220\">Tonga</option>\n                        <option value=\"221\">Trinidad And Tobago</option>\n                        <option value=\"222\">Tunisia</option>\n                        <option value=\"223\">Turkey</option>\n                        <option value=\"224\">Turkmenistan</option>\n                        <option value=\"225\">Turks And Caicos Islands</option>\n                        <option value=\"226\">Tuvalu</option>\n                        <option value=\"227\">Uganda</option>\n                        <option value=\"228\">Ukraine</option>\n                        <option value=\"229\">United Arab Emirates</option>\n                        <option value=\"230\">United Kingdom</option>\n                        <option value=\"231\">United States</option>\n                        <option value=\"232\">United States Minor Outlying Islands</option>\n                        <option value=\"233\">Uruguay</option>\n                        <option value=\"234\">Uzbekistan</option>\n                        <option value=\"235\">Vanuatu</option>\n                        <option value=\"236\">Vatican City State (Holy See)</option>\n                        <option value=\"237\">Venezuela</option>\n                        <option value=\"238\">Vietnam</option>\n                        <option value=\"239\">Virgin Islands (British)</option>\n                        <option value=\"240\">Virgin Islands (US)</option>\n                        <option value=\"241\">Wallis And Futuna Islands</option>\n                        <option value=\"242\">Western Sahara</option>\n                        <option value=\"243\">Yemen</option>\n                        <option value=\"244\">Yugoslavia</option>\n                        <option value=\"245\">Zambia</option>\n                        <option value=\"246\">Zimbabwe</option>\n                    </select>\n                    <span class=\"error\">Country is required</span>\n                </div>\n                <div class=\"form-group\">\n                    <label for=\"Closed_Date\" class=\"requiredFld\">Tender Closed Date</label>\n                    <input type=\"text\" class=\"\" name=\"Closed_Date\" id=\"Closed_Date\" aria-describedby=\"Email\" ngModel>\n                    <span class=\"error\">Tender Closed Date is required</span>\n                </div> \n                 \n                <!-- step-2  -->\n                <div class=\"form-group\">\n                    <div class=\"form-group\">\n                        <label for=\"Contract_Type\" class=\"requiredFld\">Currency</label>\n                        <select class=\"custom-select\" name=\"Currency\" id=\"Currency\" ngModel>\n                            <option selected=\"\">--Select--</option>\n                            <option value=\"1\">India -₹</option>\n                        </select>\n                        <span class=\"error\">Currency is required</span>\n                    </div>\n                </div>\n                <div class=\"form-group\">\n                    <label for=\"Opportunity_Value_Min\" class=\"requiredFld\">Opportunity Value Min</label>\n                    <input type=\"text\" class=\"\" name=\"Opportunity_Value_Min\" id=\"Opportunity_Value_Min\"  ngModel>\n                    <span class=\"error\">Opportunity Value Min is required</span>\n                </div> \n                <div class=\"form-group\">\n                    <label for=\"Opportunity_Value_Max\" class=\"requiredFld\">Opportunity Value Max</label>\n                    <input type=\"text\" class=\"\" name=\"Opportunity_Value_Max\" id=\"Opportunity_Value_Max\" ngModel>\n                    <span class=\"error\">Opportunity Value Max is required</span>\n                </div> \n\n\n                <div class=\"form-group\">\n                    <label for=\"tender_min_value\" class=\"mb-3\">Upload Tender Doc</label>\n                    <div class=\"custom-file\">\n                        <input type=\"file\" class=\"custom-file-input\" name=\"Tender_Document\" id=\"Tender_Document\" (change)=\"OnfileChange($event)\" ngModel>\n                        <label class=\"custom-file-label\" for=\"customFile\">Choose file</label>\n                        <span class=\"error\">Upload Tender Doc is required</span>\n                    </div>\n                </div> \n                <div class=\"form-group\">\n                    <label for=\"Opportunity_Description\" class=\"requiredFld\">Opportunity Description</label>\n                    <input type=\"text\" class=\"\" name=\"Opportunity_Description\" id=\"Opportunity_Description\"  ngModel>\n                    <span class=\"error\">Opportunity Description is required</span>\n                </div> \n\n\n                <!-- step-2  -->\n\n                <div class=\"button-container pb-0 text-center\">\n                <button type=\"submit\" class=\"btn btn-primary site-form-button width-auto inline-small-button step_1_Form\">Submit</button>\n                </div>\n            </div> \n        </form>\n        <pre>{{createTender.value | json}}</pre>\n\n    </div>\n    </div>\n</div>"

/***/ }),

/***/ "./src/app/components/create-tender/create-tender.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/components/create-tender/create-tender.component.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvY3JlYXRlLXRlbmRlci9jcmVhdGUtdGVuZGVyLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/components/create-tender/create-tender.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/components/create-tender/create-tender.component.ts ***!
  \*********************************************************************/
/*! exports provided: CreateTenderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateTenderComponent", function() { return CreateTenderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_dataservice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dataservice.service */ "./src/app/services/dataservice.service.ts");
/* harmony import */ var src_app_classes_tender__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/classes/tender */ "./src/app/classes/tender.ts");




var CreateTenderComponent = /** @class */ (function () {
    function CreateTenderComponent(service) {
        this.service = service;
        this.createTenderObj = new src_app_classes_tender__WEBPACK_IMPORTED_MODULE_3__["Tender"]();
    }
    CreateTenderComponent.prototype.ngOnInit = function () {
    };
    CreateTenderComponent.prototype.OnCreateTender = function (createTenderObj) {
        // console.log(this.createTenderObj.Tender_Document.name);
    };
    CreateTenderComponent.prototype.OnfileChange = function (event) {
        this.createTenderObj.Tender_Document = event.target.files[0];
        // const filetype = event.target.files === 'application/pdf' ?  this.createTenderObj.Tender_Document = event : this.createTenderObj.Tender_Document = null;
    };
    CreateTenderComponent.prototype.oncreateTenderSubmit = function (createTenderForm) {
        var fd = new FormData();
        fd.append('image', this.createTenderObj.Tender_Document, this.createTenderObj.Tender_Document.name);
        console.log(this.createTenderObj.Tender_Document);
        console.log(fd);
        this.service.createTender(fd).subscribe(function (data) {
            console.log(data);
        });
    };
    CreateTenderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-create-tender',
            template: __webpack_require__(/*! ./create-tender.component.html */ "./src/app/components/create-tender/create-tender.component.html"),
            styles: [__webpack_require__(/*! ./create-tender.component.scss */ "./src/app/components/create-tender/create-tender.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dataservice_service__WEBPACK_IMPORTED_MODULE_2__["DataserviceService"]])
    ], CreateTenderComponent);
    return CreateTenderComponent;
}());



/***/ }),

/***/ "./src/app/components/opprotunites/opprotunites.component.html":
/*!*********************************************************************!*\
  !*** ./src/app/components/opprotunites/opprotunites.component.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"primary\" class=\"opprotunites_page\">\r\n    <div class=\"FormContainer box-shadow-none p-0 m-auto\">\r\n       <form name=\"OpprotunitesForm\" action=\"\" method=\"post\" autocomplete=\"off\">\r\n           <div class=\"opprotunites_header\">\r\n               <div class=\"main_block\">\r\n                   <div class=\"row no-gutters align-items-center\">\r\n                       <div class=\"col-md-3\">\r\n                           <h2 class=\"section_card_title mb-0 border-0 p-0 font-weight-bold\">OPPORTUNITIES</h2>\r\n                       </div>\r\n                       <div class=\"col-md-9\">\r\n                           <div class=\"row\">\r\n                               <div class=\"col-md-10 search_container\">\r\n                               <div class=\"form-group mb-0\"> \r\n                                       <div class=\"searchbox\">\r\n                                        <input type=\"text\" class=\"bg-transparent\" name=\"searchtender_input\" [(ngModel)]=\"searchTender\" id=\"searchtender_input\" aria-describedby=\"Email\" placeholder=\"Search by Indutries\">\r\n                                       </div>\r\n                                   </div>\r\n                               </div>\r\n                               <div class=\"col-md-2 postTender_container\">\r\n                               <a href=\"opprotunites/CreateTender\" class=\"btn siteBtn-primary-outline-blue text-uppercase \">+ Post Tender</a>\r\n                               </div>\r\n                           </div>\r\n                       </div>\r\n                   </div>\r\n               </div>\r\n           </div> \r\n           <div class=\"opprotunites_section\">\r\n               <div class=\"main_block\">\r\n                   <div class=\"row\">\r\n                           <div class=\"col-md-3\">\r\n                              <div class=\"filter_container\">\r\n                                   <div class=\"form-group\">\r\n                                       <label for=\"user_email\">Filter Tenders</label>\r\n                                       <input type=\"text\" class=\"\" placeholder=\"Search Tenders by Title\" name=\"login_email\" [(ngModel)]=\"filterObject.Tender_Title\" id=\"login_email\" aria-describedby=\"Email\" [ngModelOptions]=\"{standalone: true}\">\r\n                                   </div>\r\n                                   <div class=\"form-group\">\r\n                                       <label for=\"filter_Industry\">Industry</label>\r\n                                       <select [(ngModel)]=\"filterObject.Industry\" class=\"form-control\" id=\"filter_Industry\" [ngModelOptions]=\"{standalone: true}\">\r\n                                           <option selected value=\"0\">Industry</option>\r\n                                           <option value=\"Computer/Information Technology\">Computer/Information Technology</option>\r\n                                           <option value=\"Accounting/Auditing/Taxation\">Accounting/Auditing/Taxation</option>\r\n                                           <option value=\"Admin/Human Resources\">Admin/Human Resources</option>\r\n                                           <option value=\"Arts/Media and Communications\">Arts/Media and Communications</option>\r\n                                           <option value=\"Events/Promotions\">Events/Promotions</option>\r\n                                           <option value=\"Garments\">Garments</option>\r\n                                           <option value=\"Electronics and Electricals\">Electronics and Electricals</option>\r\n                                           <option value=\"Industrial Suppliers\">Industrial Suppliers</option>\r\n                                           <option value=\"Hotels & Restaurants\">Hotels & Restaurants</option>\r\n                                           <option value=\"Agri Products/Commodities other\">Agri Products/Commodities other</option>\r\n                                       </select>\r\n                                   </div>\r\n                                   <div class=\"form-group\">\r\n                                       <label for=\"filter_date_posted\">Date Posted</label>\r\n                                       <select [(ngModel)]=\"filterObject.Posted_date\" class=\"form-control\" id=\"filter_date_posted\" [ngModelOptions]=\"{standalone: true}\">\r\n                                           <option value=\"0\" selected=\"selected\" >Date Posted</option>\r\n                                           <option value=\"last-24-hours\">Past 24 hours</option>\r\n                                           <option value=\"last-Week\">Past 1 Week</option>\r\n                                           <option value=\"last-Month\">Past 1 Month</option>\r\n                                           <option value=\"last-6-Month\">Past 6 Month</option>\r\n                                       </select>\r\n                                   </div>\r\n                                   <div class=\"form-group\">\r\n                                       <label for=\"filter_tenderValue\">Tender Value</label>\r\n                                       <select [(ngModel)]=\"filterObject.filterByTenderValue\"  class=\"form-control\" id=\"filter_tenderValue\" [ngModelOptions]=\"{standalone: true}\">\r\n                                           <option selected=\"selected\" value=\"0\">Tender Value</option>\r\n                                           <option value=\"below-1-lakh\">Less than 1 lakh</option>\r\n                                           <option value=\"1-lakh-to-5-lakh\">1 lakh to 5 lakh</option>\r\n                                           <option value=\"10-lakh-to-1-core\">10 lakh to 1 core</option>\r\n                                           <option value=\"above-1-core\">Above 1 core</option>\r\n                                       </select>\r\n                                   </div>\r\n                                   <div class=\"text-center\">\r\n                                       <a href=\"javascript:void(0)\" class=\"btn siteBtn-primary-outline-blue text-uppercase d-block \" (click)=\"OnSearchFilter()\">Submit</a>\r\n                                   </div>\r\n                                   <div class=\"text-center pt-3\">\r\n                                       <a href=\"javascript:void(0)\" (click)=\"OnResetSearchFilter()\" class=\"reset\">Reset</a>\r\n                                   </div>\r\n                              </div>\r\n                           </div>\r\n                       <div class=\"col-md-9 opprotunites_card_container\">\r\n                           \r\n                           <div class=\"row\">\r\n                              <div class=\"alert alert-warning\" *ngIf=\"TenderList.length < 1\">No Data Available</div>\r\n                               <div class=\"col-12 col-sm-12 col-md-6 col-lg-6 tender_card\" *ngFor=\"let tender of TenderList | filterTender : searchTender : 'searchFilter'\">\r\n                                   <div class=\"content\">\r\n                                       <div class=\"tender_header\">\r\n                                           <p class=\"m-0\">{{tender.Tender_Title}}</p>\r\n                                           <div clas=\"\">\r\n                                           <span class=\"shortlist_icon\"></span>\r\n                                           </div>\r\n                                       </div>\r\n                                       <div class=\"tender_body\">\r\n                                           <ul class=\"list-unstyled\">\r\n                                               <li><span>Contract Type :</span><span>{{tender.Contract_Type}}</span></li>\r\n                                               <li><span>Industry :</span><span>{{tender.Industry}}</span></li>\r\n                                               <li><span>Tender Value:</span><span>{{tender.Opportunity_Value_Min}} to {{tender.Opportunity_Value_Max}}</span></li>\r\n                                               <li><span>Tender Ref No :</span><span>TED{{tender.Tender_Id}}</span></li>\r\n                                           </ul>\r\n                                           <div class=\"tender_dates\">\r\n                                               <div class=\"postedDate\">\r\n                                                   <p>Posted :<span>{{tender.Posted_date | removeTime}}</span></p>\r\n                                               </div>\r\n                                               <div class=\"cloeddate\">\r\n                                                   <p>Closed :<span>{{tender.Closed_Date | removeTime}}</span></p>\r\n                                               </div>\r\n                                           </div>\r\n                                       </div>\r\n                                       <div class=\"tender_footer\">\r\n                                           <div class=\"text-right\">\r\n                                               <a href=\"Signup.php\" class=\"btn siteBtn-primary-blue text-uppercase  \">Apply</a>\r\n                                           </div>\r\n                                       </div>\r\n                                   </div>\r\n                               </div>\r\n                               <!-- <div class=\"col-12 col-sm-12 col-md-6 col-lg-6 tender_card\">\r\n                                   <div class=\"content\">\r\n                                       <div class=\"tender_header\">\r\n                                           <p class=\"m-0\">Petra Wheel Chair</p>\r\n                                           <div clas=\"\">\r\n                                           <span class=\"shortlist_icon shortlisted\"></span>\r\n                                           </div>\r\n                                       </div>\r\n                                       <div class=\"tender_body\">\r\n                                           <ul class=\"list-unstyled\">\r\n                                               <li><span>Contract Type :</span><span>Project Based</span></li>\r\n                                               <li><span>Industry :</span><span>Computer/Information Technology</span></li>\r\n                                               <li><span>Tender Value:</span><span>$200000 to 400000</span></li>\r\n                                               <li><span>Tender Ref No :</span><span>TED0000001</span></li>\r\n                                           </ul>\r\n                                           <div class=\"tender_dates\">\r\n                                               <div class=\"postedDate\">\r\n                                                   <p>Posted :<span>20/12/2019</span></p>\r\n                                               </div>\r\n                                               <div class=\"cloeddate\">\r\n                                                   <p>Closed :<span>20/12/2019</span></p>\r\n                                               </div>\r\n                                           </div>\r\n                                       </div>\r\n                                       <div class=\"tender_footer\">\r\n                                           <div class=\"text-right\">\r\n                                               <a href=\"Signup.php\" class=\"btn siteBtn-primary-blue text-uppercase  \">Apply</a>\r\n                                           </div>\r\n                                       </div>\r\n                                   </div>\r\n                               </div>\r\n                               <div class=\"col-12 col-sm-12 col-md-6 col-lg-6 tender_card\">\r\n                                   <div class=\"content\">\r\n                                       <div class=\"tender_header\">\r\n                                           <p class=\"m-0\">Petra Wheel Chair</p>\r\n                                           <div clas=\"\">\r\n                                           <span class=\"shortlist_icon\"></span>\r\n                                           </div>\r\n                                       </div>\r\n                                       <div class=\"tender_body\">\r\n                                           <ul class=\"list-unstyled\">\r\n                                               <li><span>Contract Type :</span><span>Project Based</span></li>\r\n                                               <li><span>Industry :</span><span>Computer/Information Technology</span></li>\r\n                                               <li><span>Tender Value:</span><span>$200000 to 400000</span></li>\r\n                                               <li><span>Tender Ref No :</span><span>TED0000001</span></li>\r\n                                           </ul>\r\n                                           <div class=\"tender_dates\">\r\n                                               <div class=\"postedDate\">\r\n                                                   <p>Posted :<span>20/12/2019</span></p>\r\n                                               </div>\r\n                                               <div class=\"cloeddate\">\r\n                                                   <p>Closed :<span>20/12/2019</span></p>\r\n                                               </div>\r\n                                           </div>\r\n                                       </div>\r\n                                       <div class=\"tender_footer\">\r\n                                           <div class=\"text-right\">\r\n                                               <a href=\"Signup.php\" class=\"btn siteBtn-primary-blue text-uppercase  \">Apply</a>\r\n                                           </div>\r\n                                       </div>\r\n                                   </div>\r\n                               </div>\r\n                               <div class=\"col-12 col-sm-12 col-md-6 col-lg-6 tender_card\">\r\n                                   <div class=\"content\">\r\n                                       <div class=\"tender_header\">\r\n                                           <p class=\"m-0\">Petra Wheel Chair</p>\r\n                                           <div clas=\"\">\r\n                                           <span class=\"shortlist_icon\"></span>\r\n                                           </div>\r\n                                       </div>\r\n                                       <div class=\"tender_body\">\r\n                                           <ul class=\"list-unstyled\">\r\n                                               <li><span>Contract Type :</span><span>Project Based</span></li>\r\n                                               <li><span>Industry :</span><span>Computer/Information Technology</span></li>\r\n                                               <li><span>Tender Value:</span><span>$200000 to 400000</span></li>\r\n                                               <li><span>Tender Ref No :</span><span>TED0000001</span></li>\r\n                                           </ul>\r\n                                           <div class=\"tender_dates\">\r\n                                               <div class=\"postedDate\">\r\n                                                   <p>Posted :<span>20/12/2019</span></p>\r\n                                               </div>\r\n                                               <div class=\"cloeddate\">\r\n                                                   <p>Closed :<span>20/12/2019</span></p>\r\n                                               </div>\r\n                                           </div>\r\n                                       </div>\r\n                                       <div class=\"tender_footer\">\r\n                                           <div class=\"text-right\">\r\n                                               <a href=\"Signup.php\" class=\"btn siteBtn-primary-blue text-uppercase  \">Apply</a>\r\n                                           </div>\r\n                                       </div>\r\n                                   </div>\r\n                               </div>  -->\r\n                           </div>\r\n                       </div>\r\n                   </div>\r\n               </div>\r\n           </div>\r\n       </form>\r\n       <p class=\"text-center\"> &copy; \r\n           <script>  document.write(new Date().getFullYear()); </script>   Ind-london2020.com. All rights reserved.</p>\r\n    </div>\r\n</div> "

/***/ }),

/***/ "./src/app/components/opprotunites/opprotunites.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/opprotunites/opprotunites.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvb3Bwcm90dW5pdGVzL29wcHJvdHVuaXRlcy5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/opprotunites/opprotunites.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/opprotunites/opprotunites.component.ts ***!
  \*******************************************************************/
/*! exports provided: OpprotunitesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpprotunitesComponent", function() { return OpprotunitesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_dataservice_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/dataservice.service */ "./src/app/services/dataservice.service.ts");
/* harmony import */ var src_app_classes_tender__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/classes/tender */ "./src/app/classes/tender.ts");




var OpprotunitesComponent = /** @class */ (function () {
    function OpprotunitesComponent(service, tender, filterObject) {
        this.service = service;
        this.tender = tender;
        this.filterObject = filterObject;
        this.TenderList = [];
        this.TenderList_cpy = [];
        this.people = [];
    }
    OpprotunitesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.service.getTenderDetails().subscribe(function (datas) {
            if (datas) {
                datas.forEach(function (data, index) {
                    data.Opportunity_Value_Max = +data.Opportunity_Value_Max;
                    data.Opportunity_Value_Min = +data.Opportunity_Value_Min;
                    _this.TenderList.push(data);
                    _this.TenderList_cpy = _this.TenderList;
                });
            }
        }, function (error) {
            console.log(error);
        });
    };
    OpprotunitesComponent.prototype.OnSearchFilter = function () {
        var _this = this;
        var searchFilter = this.filterObject;
        this.TenderList = this.TenderList_cpy;
        console.log(searchFilter);
        var filterTender = this.TenderList.filter(function (tender, index) {
            return ((searchFilter.hasOwnProperty('Tender_Title') ? tender.Tender_Title.includes(searchFilter.Tender_Title) : true) && (searchFilter.hasOwnProperty('Industry') ? tender.Industry === searchFilter.Industry : true) && _this.AmountFilter(tender, searchFilter) && _this.filterByJoinDate(tender, searchFilter));
        });
        this.TenderList = filterTender;
    };
    OpprotunitesComponent.prototype.OnResetSearchFilter = function () {
        this.filterObject = new src_app_classes_tender__WEBPACK_IMPORTED_MODULE_3__["SearchTenderFilter"]();
        this.TenderList = this.TenderList_cpy;
    };
    OpprotunitesComponent.prototype.AmountFilter = function (tender, fliterObj) {
        return fliterObj.hasOwnProperty('filterByTenderValue') ? this.AmountFormetCostomization(tender, fliterObj) : true;
    };
    OpprotunitesComponent.prototype.filterByJoinDate = function (user, fliterObj) {
        return fliterObj.hasOwnProperty('Posted_date') ? this.DateFormetCustomization(user, fliterObj) : true;
    };
    OpprotunitesComponent.prototype.AmountFormetCostomization = function (tender, fliterObj) {
        switch (fliterObj.filterByTenderValue) {
            case 'below-1-lakh':
                return tender.Opportunity_Value_Max < 100000;
                break;
            case '1-lakh-to-5-lakh':
                return tender.Opportunity_Value_Max >= 100000 && tender.Opportunity_Value_Max <= 500000;
                break;
            case '10-lakh-to-1-core':
                return tender.Opportunity_Value_Max >= 1000000 && tender.Opportunity_Value_Max <= 1000000;
                break;
            case 'above-1-core':
                return tender.Opportunity_Value_Max > 1000000;
                break;
            default:
                return true;
                break;
        }
    };
    OpprotunitesComponent.prototype.DateFormetCustomization = function (tender, fliterObj) {
        var currentDate = new Date();
        switch (fliterObj.Posted_date) {
            case 'last-24-hours':
                return this.getsecoundsDiffbt(new Date().getTime(), new Date(tender.Posted_date).getTime()) === 1 ? true : false;
                break;
            case 'last-Week':
                return this.getsecoundsDiffbt(new Date().getTime(), new Date(tender.Posted_date).getTime()) <= 7 ? true : false;
                break;
            case 'last-Month':
                return this.getsecoundsDiffbt(new Date().getTime(), new Date(tender.Posted_date).getTime()) <= 31 ? true : false;
                break;
            case 'last-6-Month':
                return this.getsecoundsDiffbt(new Date().getTime(), new Date(tender.Posted_date).getTime()) <= (31 * 6) ? true : false;
                break;
            default:
                return true;
                break;
        }
    };
    OpprotunitesComponent.prototype.getsecoundsDiffbt = function (Date1, Date2) {
        var diffsec = Math.abs(Date1 - Date2);
        var diffDays = Math.ceil(diffsec / (1000 * 3600 * 24));
        return diffDays;
    };
    OpprotunitesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-opprotunites',
            template: __webpack_require__(/*! ./opprotunites.component.html */ "./src/app/components/opprotunites/opprotunites.component.html"),
            styles: [__webpack_require__(/*! ./opprotunites.component.scss */ "./src/app/components/opprotunites/opprotunites.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_dataservice_service__WEBPACK_IMPORTED_MODULE_2__["DataserviceService"], src_app_classes_tender__WEBPACK_IMPORTED_MODULE_3__["Tender"], src_app_classes_tender__WEBPACK_IMPORTED_MODULE_3__["SearchTenderFilter"]])
    ], OpprotunitesComponent);
    return OpprotunitesComponent;
}());



/***/ }),

/***/ "./src/app/pipes/removeTime.ts":
/*!*************************************!*\
  !*** ./src/app/pipes/removeTime.ts ***!
  \*************************************/
/*! exports provided: RemoveTime */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RemoveTime", function() { return RemoveTime; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var RemoveTime = /** @class */ (function () {
    function RemoveTime() {
    }
    RemoveTime.prototype.transform = function (date) {
        return date.split(' ')[0];
    };
    RemoveTime = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'removeTime'
        })
    ], RemoveTime);
    return RemoveTime;
}());



/***/ }),

/***/ "./src/app/pipes/tendersearchbyindustry.ts":
/*!*************************************************!*\
  !*** ./src/app/pipes/tendersearchbyindustry.ts ***!
  \*************************************************/
/*! exports provided: FilterTender */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterTender", function() { return FilterTender; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var FilterTender = /** @class */ (function () {
    function FilterTender() {
    }
    FilterTender.prototype.transform = function (value, args, args_1) {
        if (!value) {
            return null;
        }
        if (!args) {
            return value;
        }
        args = args.toLowerCase();
        return value.filter(function (item) {
            return JSON.stringify(item).toLowerCase().includes(args);
        });
    };
    FilterTender = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
            name: 'filterTender'
        })
    ], FilterTender);
    return FilterTender;
}());



/***/ }),

/***/ "./src/app/route/app-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/route/app-routing.module.ts ***!
  \*********************************************/
/*! exports provided: APP_ROUTING */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "APP_ROUTING", function() { return APP_ROUTING; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _components_opprotunites_opprotunites_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/opprotunites/opprotunites.component */ "./src/app/components/opprotunites/opprotunites.component.ts");
/* harmony import */ var _components_create_tender_create_tender_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/create-tender/create-tender.component */ "./src/app/components/create-tender/create-tender.component.ts");



var MAINMENU_ROUTES = [
    { path: '', redirectTo: 'opprotunites', pathMatch: 'full' },
    { path: '**', redirectTo: '404' },
    { path: 'opprotunites', component: _components_opprotunites_opprotunites_component__WEBPACK_IMPORTED_MODULE_1__["OpprotunitesComponent"], data: { state: 'opprotunites' } },
    { path: 'opprotunites/CreateTender', component: _components_create_tender_create_tender_component__WEBPACK_IMPORTED_MODULE_2__["CreateTenderComponent"], data: { state: 'CreateTender' } },
];
var APP_ROUTING = _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(MAINMENU_ROUTES, { useHash: false });


/***/ }),

/***/ "./src/app/services/dataservice.service.ts":
/*!*************************************************!*\
  !*** ./src/app/services/dataservice.service.ts ***!
  \*************************************************/
/*! exports provided: DataserviceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataserviceService", function() { return DataserviceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");




var DataserviceService = /** @class */ (function () {
    function DataserviceService(http) {
        this.http = http;
        this.WebServiceUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].WebServiceUrl;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        };
    }
    DataserviceService.prototype.listUser = function () {
        return this.http.get(this.WebServiceUrl + '/api/users');
    };
    DataserviceService.prototype.sigleUser = function () {
        return this.http.get(this.WebServiceUrl + '/api/users');
    };
    DataserviceService.prototype.getTenderDetails = function () {
        return this.http.get(this.WebServiceUrl + '/tender/TenderDetails');
    };
    DataserviceService.prototype.createTender = function (data) {
        // /tender/CreateTender
        return this.http.post(this.WebServiceUrl + '/file-upload.php', {
            'name': 'praveen',
            'description': 'kumar',
            'document': data
        });
    };
    DataserviceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], DataserviceService);
    return DataserviceService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
var environment = {
    production: false,
    version: 'Dev',
    WebServiceUrl: 'http://localhost/projects/IndoUKB2B-api',
    relpath: '/Projects/Workplace/INDOUKB2B/'
    // WebServiceUrl : 'https://betaindukpraveenfreelancer.000webhostapp.com/IndoUKB2B-api/IndoUKB2B-api/',
    // relpath: '/INDOUKB2B/'
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\xampp\htdocs\Projects\Workplace\INDOUKB2B\ng-app\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map